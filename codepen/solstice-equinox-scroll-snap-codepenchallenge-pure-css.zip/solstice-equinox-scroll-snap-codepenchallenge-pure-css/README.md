# Solstice & Equinox (Scroll Snap #CodePenChallenge) [pure CSS]

A Pen created on CodePen.

Original URL: [https://codepen.io/denisetrocchi/pen/ExzEOdJ](https://codepen.io/denisetrocchi/pen/ExzEOdJ).

We've just welcomed the solstice (summer solstice, here north of the equator)... so why not embark (oops, scroll!) on an astronomical-themed journey? Just a bit of scroll-snap and we're on board — and if you're using Chrome, you can also enjoy a touch of (basic) CSS scroll-driven animations!
[Please note that this is just an approximation to illustrate the stages of solstices and equinoxes (so no Moon, aphelion, or perihelion… but feel free to fork and play around ;) ] | CodePen Challenge, June 2024, "Scroll Snap"