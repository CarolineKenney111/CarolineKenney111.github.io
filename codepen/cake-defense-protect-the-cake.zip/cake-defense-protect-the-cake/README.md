# Cake Defense: Protect the cake

A Pen created on CodePen.

Original URL: [https://codepen.io/housamz/pen/yyBRJpJ](https://codepen.io/housamz/pen/yyBRJpJ).

