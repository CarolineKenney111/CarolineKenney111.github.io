# Seeing Stars 🌟 Animating @property values with @keyframes (Chromium only)

A Pen created on CodePen.

Original URL: [https://codepen.io/meowwwls/pen/mdYVQJx](https://codepen.io/meowwwls/pen/mdYVQJx).

