# Catch Me If You Can

A Pen created on CodePen.

Original URL: [https://codepen.io/jkantner/pen/ZYEQwLB](https://codepen.io/jkantner/pen/ZYEQwLB).

A cat-and-mouse kind of spinner!